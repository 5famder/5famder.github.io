TC_COURSE_ID = "http://FUvjXIYoUjLA5tL4XQHyChw7bJdgaL2A_rise";
TC_COURSE_NAME = {"en":"Your First Inference Request: From API Key to Model Response"};
TC_COURSE_DESC = {"en":"A 20-minute module for developers making their first call to a hosted model API. You will create an API key, send a chat-completion request from Python, read the response object, and adjust the two parameters you will change most often. No infrastructure knowledge required."};
